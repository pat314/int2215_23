#include <bits/stdc++.h>
using namespace std;

const int MAX_BAD_GUESS = 7;

const string FIGURE[] = {
         "   -------------    \n" 
         "   |                \n" 
         "   |                \n" 
         "   |                \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",

         "   -------------    \n" 
         "   |           |    \n" 
         "   |                \n" 
         "   |                \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",

         "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |                \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",
 "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |           |    \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",

         "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |          /|    \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",

         "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |          /|\\  \n" 
         "   |                \n" 
         "   |     \n" 
         " -----   \n",
 "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |          /|\\  \n" 
         "   |          /     \n" 
         "   |     \n" 
         " -----   \n",

         "   -------------    \n" 
         "   |           |    \n" 
         "   |           O    \n" 
         "   |          /|\\  \n" 
         "   |          / \\  \n" 
         "   |     \n" 
         " -----   \n",
};


string chooseWord()
{
	int wordCount=0;
	string wordList[1000];
	ifstream input ("wordlist.txt");
	while (input)
	{
		input>>wordList[wordCount++];
	}
	int randomIndex = rand()%wordCount;
	return wordList[randomIndex];
}

void renderGame(string guessedWord, int badGuessCount)
{
	cout << guessedWord << endl;
	cout << "Number of wrong guesses: " << badGuessCount << endl;
	cout<<FIGURE[badGuessCount];
}

string update(string guessedWord, string secretWord, char guess)
{
	for (int i = secretWord.length() - 1; i >= 0; i--) {
        if (secretWord[i] == guess) {
            guessedWord[i] = guess;
        }
    }
    return guessedWord;
}
char readAGuess(){
	char a;
	cin>>a;
	return a;
}
bool contains(string secretWord, char guess){
	int len1 = secretWord.length();
	int a = secretWord.find_first_of(guess);
	if (a>=0 && a<len1) return true;
	else return false;
}

int main()
{
	
	srand(time(0));
	string secretWord = chooseWord();
	//cout<<secretWord;
	//return 0;
	string guessedWord = string (secretWord.length(),'-');
	int badGuessCount = 0;
	
	do
	{
		cout<<"              HANGMAN v0.1\n*****************************************\nHidden word:\n";
		renderGame(guessedWord, badGuessCount);
		cout<<"Enter your guess word here:"<<endl;
		
		char guess = readAGuess();
		if (contains(secretWord, guess))
			guessedWord = update(guessedWord, secretWord, guess);
		else badGuessCount++;
		system("cls");
	}
	while (badGuessCount < MAX_BAD_GUESS && secretWord != guessedWord);
	
	cout<<"              HANGMAN v0.1\n*****************************************\nHidden word:\n";
	renderGame (guessedWord, badGuessCount);
	if (badGuessCount < 7) cout << "Congratulations! You win!";
	else cout << "You lost. The correct word is " << secretWord;
}
